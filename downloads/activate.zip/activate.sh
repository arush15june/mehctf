source mehctf/bin/activate

